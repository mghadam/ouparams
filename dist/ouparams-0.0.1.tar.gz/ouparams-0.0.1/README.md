# ouparams
A python module to Find Process Parameters for Ornstein-Uhlenbeck Processes

# Usage
```
import ouparams
mu, sigma, theta = ouparams.calc(data)
```
